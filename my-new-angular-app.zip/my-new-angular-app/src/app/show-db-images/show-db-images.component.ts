import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-show-db-images',
  templateUrl: './show-db-images.component.html',
  styleUrls: ['./show-db-images.component.css']
})
export class ShowDbImagesComponent implements OnInit {

  products:any
  constructor(private service:CustomerService) {
   
   }

  ngOnInit(): void {
   
    this.service.getProducts().subscribe((result:any) => {console.log(result);this.products=result;});
 
 
  }

}




