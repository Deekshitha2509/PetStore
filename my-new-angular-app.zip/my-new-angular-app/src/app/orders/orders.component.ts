import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { CustomerService } from './../customer.service';
import { Router } from '@angular/router';

declare var jQuery:any;


@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

customer:any;
customerId:any;
orders:any;
ordDetails:any;
ord:any;

  constructor(private service :CustomerService,private router:Router) { }

  ngOnInit(): void {
    this.customer =  JSON.parse(localStorage.getItem('currentUser'));
    this.customerId = this.customer.customerId;
    console.log(this.customerId);
    this.service.getOrdersByCustomerId(this.customerId).subscribe((result: any) => { console.log(result); this.orders = result; });
  
  }

  
  details(ord){
    
    this.service.getOrderDetailsByOrderId(ord.orderId).subscribe((result: any) => { console.log(result); this.ordDetails = result; });
    jQuery('#orderDetailsModel').modal('show');
  }

}
