import { Component, OnInit } from '@angular/core';

import { CustomerService } from '../customer.service';
import { HttpClient } from '@angular/common/http';
import { LocalstorageService } from '../localstorage.service';


import { Router } from '@angular/router';
declare var jQuery:any;

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  
  customer: any;
  cartItem:any;
  cartItems: any;
  product : any;
  products: any;
  constructor(private service: CustomerService, private router:Router,private http:HttpClient) {
    this.cartItem=[];
    this.cartItems=this.service.cartItems;
    this.product={productId:'' , category:'', description:'',price:'',imageName:''};
   }
  ngOnInit() {
    this.service.getProducts().subscribe((result: any) => { console.log(result); this.products = result; });
    sessionStorage.setItem('products', JSON.stringify(this.products));
  }

  showpopup(product:any){
      this.cartItem.product = product;
      this.cartItem.imageName = product.image;
      this.cartItem.price = product.price;
      this.cartItem.quantity = 0;
  
      jQuery('#quantityModel').modal('show');
    }

    addToCart(){
      console.log(this.service.isUserLogged);
      if(this.service.isUserLogged === false){
        this.router.navigate(['login']);
      }
      else{
      this.customer = JSON.parse(localStorage.getItem('currentUser'));

      this.cartItem.totalPrice = Number(this.cartItem.quantity) * Number(this.cartItem.price);
      this.service.addToCart(this.cartItem);
      console.log('Inside add to cart ', this.cartItem);
      }
    }

    goToCart(){
      console.log(this.service.isUserLogged);
      if(this.service.isUserLogged == false){
        this.router.navigate(['login']);
      }
      else{
      this.customer = JSON.parse(localStorage.getItem('currentUser'));
  
      this.router.navigate(['cart']);
      }

    }
    goToOrders(){
      this.router.navigate(['orders']);
    }
    callLogOut() {
      this.router.navigate(['login']);
    }
    routeToMyOrders() {
      this.customer = JSON.parse(localStorage.getItem('currentUser'));
      this.router.navigate(['order-history']);
  
    }
    


}  
