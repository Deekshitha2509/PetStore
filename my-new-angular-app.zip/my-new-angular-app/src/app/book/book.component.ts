import { Component, OnInit } from '@angular/core';
import { CustomerService } from './../customer.service';
import { RouterModule, Router } from '@angular/router'; 
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';
import { AstMemoryEfficientTransformer } from '@angular/compiler';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  services: any;
  serviceForm: any
  user: any;
  customer:any;
  price:any;
  d: any;
  login: any;
  constructor(private router: Router,private service: CustomerService) {
    this.services = {serviceId: '',name: '',petType:'',numOfDays:'',fromDate:'', serviceAddress:'',phoneno:'',totalPrice:''}; 
      
   }

  ngOnInit(): void {
    this.user=this.service.getDetails();
    this.serviceForm=JSON.parse(localStorage.getItem('curServiceForm'));
    this.customer = JSON.parse(localStorage.getItem('currentUser'));
    this.login.email = JSON.parse(localStorage.getItem('curLogin'));

  }

  serviceregisterSubmit(serviceForm: any): void {
    this.customer = JSON.parse(localStorage.getItem('currentUser'));
   // this.d = JSON.parse(localStorage.getItem('serviceForm'));
    if(this.services.numOfDays < 7){
         this.price = (this.services.numOfDays *500);
         } 
         else{
          this.price = (this.services.numOfDays *400);
         }     
   // this.services.customerId = this.user
   this.services.totalPrice=this.price; 
    this.service.registerServices(this.services).subscribe((result: any) => { 
    //  this.service.setCustomer('customer',JSON.stringify(result));
     // this.router.navigate(['login']);
      console.log(result);
      

     } );
      localStorage.setItem('serviceForm',JSON.stringify(serviceForm));
      this.d = JSON.parse(localStorage.getItem('serviceForm'));

      //this.service.email(this.services); 

     
     
    console.log(serviceForm);
    this.router.navigate(['receipt']);
  }

}
