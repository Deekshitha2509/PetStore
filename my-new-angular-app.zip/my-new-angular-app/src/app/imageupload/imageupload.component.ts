import { Component, OnInit } from '@angular/core';
import { CustomerService } from './../customer.service';


@Component({
  selector: 'app-imageupload',
  templateUrl: './imageupload.component.html',
  styleUrls: ['./imageupload.component.css']
})
export class ImageuploadComponent implements OnInit {
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  constructor(private service: CustomerService) { 
    this.imageUrl = 'assets/images/dog.jpg';

  }

  ngOnInit(): void {
  }
  handleFileInput(file: FileList) {
    this.fileToUpload = file.item(0);

    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }

  OnSubmit(imageForm: any){
    this.service.postFile(imageForm, this.fileToUpload).subscribe(
     data => {
      // localStorage.setItem('dietplan',JSON.stringify(imageForm));
       console.log('done');
       this.imageUrl = 'assets/images/dog.jpg';

     }
    
    );

    }
  }
