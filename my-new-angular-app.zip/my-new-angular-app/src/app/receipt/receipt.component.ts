import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';


@Component({
  selector: 'app-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.css']
})
export class ReceiptComponent implements OnInit {
   d: any;
   customer: any;
  price:any;
  constructor(private service:CustomerService) { }

      

  ngOnInit(): void {

    this.customer = JSON.parse(localStorage.getItem('currentUser'));
    this.d = JSON.parse(localStorage.getItem('serviceForm'));
    if(this.d.numOfDays < 7){
         this.price = (this.d.numOfDays *500);
         } 
         else{
          this.price = (this.d.numOfDays * 400);
         }     
  }
  /*getPrice(serviceName:any){
    this.service.getPriceByServiceName(serviceName).subscribe((result: any) => {console.log("Inside ts",result); this.myServices = result; });

  } */
        

}
