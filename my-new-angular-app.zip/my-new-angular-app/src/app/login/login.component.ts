import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router ,ActivatedRoute} from '@angular/router';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  customerdetails: any;
  customer:any;
  
  imageUrl2: string;

  constructor(private router: Router ,private service:CustomerService,private toastr: ToastrService) { 
    
    this.imageUrl2='/assets/images/bg_01.jpg'

    this.customerdetails = {email: '',password:''};
  }

  ngOnInit(): void {
    this.customer = JSON.parse(localStorage.getItem('currentUser'));

  }
  
   async loginSubmit(loginForm:any){
     if(loginForm.email==='admin' && loginForm.password==='admin'){
       this.service.setUserLoggedIn();
       this.router.navigate(['main']);
     } else{
      
     await this.service.loginCustomer(loginForm.email, loginForm.password).then((result: any) => {
         console.log(loginForm);
    if(result != null){
      this.service.setUserLoggedIn();
      localStorage.setItem('currentUser',JSON.stringify(result));
      this.router.navigate(['main']);
    } else {
      this.toastr.error('Invalid Credentials','Login Failed');
    }
    localStorage.setItem('curLogin',JSON.stringify(this.customerdetails));

  }, 
  
   (error)=> {

  })
}
   }
currentUser(){
  return JSON.parse(localStorage.getItem('currentUser'));
}
}


