import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { CustomerService } from './../customer.service';

import { LocalstorageService } from '../localstorage.service';


import { Router } from '@angular/router';
declare var jQuery:any;


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})

export class CartComponent implements OnInit {
  cartItems:any;
  editObject:any;
  customer:any;
  amount:any;
  atime:any;
  address:any;
  constructor(private service :CustomerService,private router:Router) {
    this.cartItems=this.service.cartItems;
    this.amount=this.service.amount;
    this.editObject={};
    console.log(this.service.cartItems);
    this.customer =  JSON.parse(localStorage.getItem('currentUser'));
    this.address='';
   }

  ngOnInit(): void {
   
    
  }

  Buy(){
    console.log(this.customer);
    this.service.confirmOrders(this.customer,this.amount,this.cartItems,this.address).subscribe();
    alert("order placed successfully");
  }

  delete(item:any){
    this.service.delete(item);
    this.amount=this.service.amount;
  
  }
  edit(item:any){
      this.editObject=item;
      alert('edit called');
      jQuery('#quantityModel2').modal('show');
      this.amount=this.service.amount;
  }
  update(){
    this.service.update(this.editObject);
    this.amount=this.service.amount;
  }
  
  showpopup2(){
    jQuery('#addressModel').modal('show');
  
  }
  routeToMyOrders() {
    this.customer = JSON.parse(localStorage.getItem('currentUser'));
    this.router.navigate(['orders']);

  }
  callHome() {
    this.router.navigate(['home']);
  }
}



