import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ToastrModule} from 'ngx-toastr';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';

import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router'; 
import { HttpClientModule } from '@angular/common/http';
import { MainComponent } from './main/main.component';
import { MyprofileComponent } from './myprofile/myprofile.component';
import { ImageuploadComponent } from './imageupload/imageupload.component';

import { ServicepageComponent } from './servicepage/servicepage.component';
import { BookComponent } from './book/book.component';
import { ShowDbImagesComponent } from './show-db-images/show-db-images.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ReceiptComponent } from './receipt/receipt.component';
import { CartComponent } from './cart/cart.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { OrdersComponent } from './orders/orders.component';


const appRoot: Routes = [{path: '', component: HomeComponent},
                         {path: 'register', component: RegisterComponent},
                         {path: 'login', component: LoginComponent},
                         {path: 'register/login', component: LoginComponent},
                         {path: 'main', component: MainComponent},
                         {path: 'myprofile', component: MyprofileComponent},
                         {path: 'products', component: ProductsComponent},
                         
                         {path: 'servicepage', component: ServicepageComponent},
                         {path: 'aboutus', component: AboutusComponent},
                         {path: 'forgotpassword', component: ForgotpasswordComponent},
                         {path: 'cart', component: CartComponent},
                         {path: 'orders', component: OrdersComponent},
                        {path: 'book', component: BookComponent},
                        {path: 'receipt', component: ReceiptComponent}
                        

                      
                         
                        ];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    MainComponent,
    MyprofileComponent,
    ProductsComponent,
    ImageuploadComponent,
    ServicepageComponent,
    
    CartComponent,
    
    BookComponent,
    
    ShowDbImagesComponent,
    
    AboutusComponent,
    
    ReceiptComponent,
    
    CartComponent,
  
    
    ForgotpasswordComponent,
    
    OrdersComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoot),
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot()
    /*  {
      timeOut: 500,
      positionClass: 'toast-top-right',
      preventDuplicates: false,
    } */

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
