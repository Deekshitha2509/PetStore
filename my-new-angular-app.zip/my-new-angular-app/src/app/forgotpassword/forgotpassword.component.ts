import { Component, OnInit } from '@angular/core';
import { CustomerService } from './../customer.service';
import { ToastrService } from 'ngx-toastr';

declare var jQuery: any;

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  user: any;
  email : any;
  editObject : any;
  constructor(private service: CustomerService, private toastr: ToastrService) { 
    this.editObject = {customerId: '', customerName: '', mobileNum: '',email: '',address: '',password:''};
  }

  ngOnInit(): void {
    
  }
  ChangePassword(): any {

    this.service.getCustomer1(this.email).subscribe((result: any) => {console.log(result); this.user = result;
    console.log("hello" + this.user);
    this.editObject = this.user;
    jQuery('#empEditPopup').modal('show');
    //this.showEditPopup(this.user);
    console.log("Hi");
    });
  }
  showEditPopup() {
    this.service.getCustomer1(this.email).subscribe((result: any) => {console.log(result); this.user = result;
      console.log("hello" + this.user);
      this.editObject = this.user;
      jQuery('#empEditPopup').modal('show');
      //this.showEditPopup(this.user);
      console.log("Hi");
      });
  }
  
  verify() {
    this.service.getCustomer1(this.email).subscribe((result: any) => {console.log(result); this.user = result;
    if(this.user==null) {
     this.toastr.error('','Not Registered EmailId');
    } else {
     this.toastr.success('','Credentials sent to mail');
    }
    });
  }
 

}
