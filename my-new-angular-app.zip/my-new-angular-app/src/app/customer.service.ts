import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { LocalstorageService } from './localstorage.service';
import * as _ from 'underscore';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  public isUserLogged: any;
  private user: any;
  private object: any;
  cartItems=[];
  amount = 0;
  cartItem:any;
  displayCartItems=[];
  constructor(private httpClient: HttpClient,private localstorage: LocalstorageService) { 
    this.isUserLogged = false;
    this.cartItem={productId:'',imageName:' ', price:'', quantity:'', totalPrice:''};
  }


  addToCart(cartItem:any){
    var element = _.findWhere(this.cartItems,{productId: cartItem.product.productId});
    if(typeof(element) == 'undefined' && element == null){
      console.log('Cart Item : ', cartItem.product);
      this.displayCartItems.push({product:cartItem.product,quantity:cartItem.quantity,totalPrice:cartItem.totalPrice});
      console.log('Cart Items : ', this.cartItems);
      this.cartItems.push({productId: cartItem.product.productId ,quantity  : cartItem.quantity, price: cartItem.price, totalPrice: cartItem.totalPrice});
   }else{
    element.quantity = parseInt(element.quantity)  + parseInt(cartItem.quantity);
    element.totalPrice = parseInt(element.quantity) * parseFloat(element.price);
  }this.calcAmount();
  }

  calcAmount():any{
    this.amount=0;
    for(let i = 0; i < this.cartItems.length;i++){
  
      this.amount+= parseFloat(this.cartItems[i].totalPrice);
        console.log(this.cartItems[i].totalPrice)
      }
      console.log(this.amount)
  }

   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   setUserLoggedOut(): void { // logout success
    this.isUserLogged = false;
   }
   getUserLogged(): any { // call this in AuthGuard
     return this.isUserLogged;
   }
  /* getCountriesList(): any {
    return this.httpClient.get('https://restcountries.eu/rest/v2/all');
   } */
   loginCustomer(email: string, password: string): any{
    this.user = this.httpClient.get('RESTAPI/webapi/myresource/loginCustomer/' + email + '/' + password).toPromise();
    return this.user;
  }
   setCustomer(key:any, customer: any){
    return this.localstorage.set(key,customer);
  }
  
  getCustomer(key:any){
    return this.localstorage.get(key);

  }
  getProducts():any{
    return this.httpClient.get('RESTAPI/webapi/myresource/getAllProducts');
  }

  updateCustomer(editObject:any){
    return this.httpClient.put('RESTAPI/webapi/myresource/updateCustomer', editObject);
  }

   registerCustomer(customer: any) {
    return this.httpClient.post('RESTAPI/webapi/myresource/registerCustomer/', customer);
   }

   registerServices(services: any){
    return this.httpClient.post('RESTAPI/webapi/myresource/registerServices/', services);
   }
   
   email(services: any){
    return this.httpClient.post('RESTAPI/webapi/myresource/email/', services);


   }
   setServices(key:any, services: any){
    return this.localstorage.set(key,services);
  }

  viewMyCart(customerId: any) {
    return this.httpClient.get('RESTAPI/webapi/myresource/viewMyCart/' + customerId);
  }

  placeOrder(customerId: any) {
    return this.httpClient.post('RESTAPI/webapi/myresource/placeOrder/', customerId);
  }
  removeFromCart(cartId: any) {
    return this.httpClient.delete('RESTAPI/webapi/myresource/removeFromCart/' + cartId);
  }
  

  confirmOrders(customer:any,amount:any,cartItems:any,address:any){
    // console.log("service");
    // console.log(orderType);
    // console.log(amount);
    // console.log(bookDetails);
    // console.log('Inside Service : ', this.cartItems);
    const formData:FormData = new FormData();
    formData.append('customerId', customer.customerId);
    console.log(customer.customerId);
    console.log('Inside Service : ', this.cartItems);
    formData.append('items', JSON.stringify(this.cartItems));
    formData.append('amount', amount);
    formData.append('address',address);
    console.log(amount);
    this.displayCartItems.splice(0, this.cartItems.length);
    return this.httpClient.post('RESTAPI/webapi/myresource/confirmOrders', formData);
    }
    
    delete(item:any){
    const i = this.cartItems.findIndex((element) => { return element.productId == item.productId;});
    this.cartItems.splice(i , 1);
    this.displayCartItems.splice(i , 1);
    this.calcAmount();
    }
    
    update(editObject:any){
    var element = _.findWhere(this.cartItems,{productId:editObject.productId});
    console.log(element);
    element.quantity=editObject.quantity;
    element.totalPrice = parseInt(editObject.quantity) * parseFloat(editObject.price);
    this.calcAmount();
    }

    getOrdersByCustomerId(customerId:any){
      console.log("api called");
      return this.httpClient.get('RESTAPI/webapi/myresource/getOrdersByCustomerId/' + customerId);
      }
      
      getOrderDetailsByOrderId(orderId:any){
      return this.httpClient.get('RESTAPI/webapi/myresource/getOrderDetailsByOrderId/'+ orderId);
      }
      
    
    
  searchProduct(productName: any) {
    return this.httpClient.get('RESTAPI/webapi/myresource/searchProduct/'+ productName);
  }

  viewMyProductsAdded(customerId: any) {
    console.log(customerId);
    return this.httpClient.get('RESTAPI/webapi/myresource/viewMyProducts/' + customerId);
  }

  deleteMyProduct(product: any) {
    return this.httpClient.delete('RESTAPI/webapi/myresource/deleteMyProductAdded/' + product.productId);
  }

                           
  getCustomer1(email: any): any {
    return this.httpClient.get('RESTAPI/webapi/myresource/getCustomer1/' + email);
  }
 
  postFile(ImageForm:any,fileToUpload:File){

    const endpoint = 'RESTAPI/webapi/myresource/uploadImage';
    const formData:FormData = new FormData();
    formData.append('Image',fileToUpload,fileToUpload.name);
    formData.append('productName',ImageForm.productName);
    formData.append('description',ImageForm.description);
    
    formData.append('price', ImageForm.price);

    console.log("in service");
    
    return this.httpClient.post(endpoint,formData);
  }



 /*  postFile(ImageForm: any, fileToUpload: File) {
     const endpoint ='RESTAPI/webapi/myresource/uploadImage';
     const formData: FormData = new FormData();
     console.log("hello");
     console.log(ImageForm);
     formData.append('Image', fileToUpload, fileToUpload.name);
     formData.append('productName', ImageForm.productName);
     formData.append('description', ImageForm.description);
     formData.append('price', ImageForm.price);
     return this.httpClient.post(endpoint, formData); 


    } */
    
    getDetails() {
      return this.object;
     }
   /* getPriceByServiceName(serviceName:any):any{
      return this.httpClient.get('RESTAPI/webapi/myresource/getPriceByServiceName/'+ serviceName);
    }
   
   deleteEmp(employee: any) {
    return this.httpClient.delete('RESTAPI/webapi/myresource/deleteEmp/' + employee.empId);
   }

   updateEmp(editObject: any) {
    return this.httpClient.put('RESTAPI/webapi/myresource/updateEmp', editObject);
   }  */

  
  }
