import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { CustomerService } from '../customer.service';

import { LocalstorageService } from '../localstorage.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
declare var jQuery:any;


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})


export class ProductsComponent implements OnInit {
  customer: any;
  cartItem:any;
  cartItems: any;
  product : any;
  products: any;
  constructor(private service: CustomerService, private router:Router,private http:HttpClient) {
    this.cartItem=[];
    this.cartItems=this.service.cartItems;
    this.product={productId:'' , category:'', description:'',price:'',imageName:''};
   }
  ngOnInit() {
    this.service.getProducts().subscribe((result: any) => { console.log(result); this.products = result; });
    sessionStorage.setItem('products', JSON.stringify(this.products));
  }

  showpopup(product:any){
      this.cartItem.product = product;
      this.cartItem.imageName = product.image;
      this.cartItem.price = product.price;
      this.cartItem.quantity = 0;
  
      jQuery('#quantityModel').modal('show');
    }

    addToCart(){
      console.log(this.service.isUserLogged);
      if(this.service.isUserLogged === false){
        this.router.navigate(['login']);
      }
      else{
      this.customer = JSON.parse(localStorage.getItem('currentUser'));

      this.cartItem.totalPrice = Number(this.cartItem.quantity) * Number(this.cartItem.price);
      this.service.addToCart(this.cartItem);
      console.log('Inside add to cart ', this.cartItem);
      }
    }

    goToCart(){
      console.log(this.service.isUserLogged);
      if(this.service.isUserLogged == false){
        this.router.navigate(['login']);
      }
      else{
      this.customer = JSON.parse(localStorage.getItem('currentUser'));
  
      this.router.navigate(['cart']);
      }

    }
    goToOrders(){
      this.router.navigate(['orders']);
    }
    callLogOut() {
      this.router.navigate(['login']);
    }
    routeToMyOrders() {
      this.customer = JSON.parse(localStorage.getItem('currentUser'));
      this.router.navigate(['order-history']);
  
    }
    

}
  /*
  products: any;
  editObject:any;
  customer: any;
  searchedProduct: any;
  productName: any;
  login: any;
  constructor(private service: CustomerService, private local: LocalstorageService, private router: Router) { 
    this.editObject={customerId: '', customerName: '', mobileNum:'',address: '', email: '',password:''}

  }
  ngOnInit() {
    this.service.getProducts().subscribe((result:any) => {console.log(result);this.products=result;});
    this.customer = JSON.parse(localStorage.getItem('currentUser'));
    this.login.email = JSON.parse(localStorage.getItem('curLogin'));
  }

  showEditPopup(){
    this.editObject = this.customer;
    console.log(this.editObject);
    jQuery('#custModel').modal('show');
  }
  updateCustomer() {
    this.service.updateCustomer(this.editObject).subscribe();
    console.log(this.editObject)
  }
  callLogOut() {
    this.router.navigate(['login']);
  }
 
  routeToViewMyCart() {
    console.log(this.service.isUserLogged);
    if(this.service.isUserLogged == false){
      this.router.navigate(['login']);
    }
    else{
    this.customer = JSON.parse(localStorage.getItem('currentUser'));

    this.router.navigate(['cart']);
    }
  }
  
  routeToMyOrders() {
    this.customer = JSON.parse(localStorage.getItem('currentUser'));
    this.router.navigate(['order-history']);

  }
  callHome() {
    this.router.navigate(['home']);
  }

  handleAddToCart(product: any,quantity:any) {
    if(this.service.isUserLogged == false){
      this.router.navigate(['login']);
    }
    else{
    this.customer = JSON.parse(localStorage.getItem('currentUser'));
    const i = this.products.findIndex((element)=>{return element.productId === product.productId;});
    this.service.addToCart(this.customer.customerId,this.products[i].productId,quantity).subscribe((result:any)=>console.log(result));
    }
  } 

  

  searchProduct(productName: any) {
    this.productName = productName;
    this.service.searchProduct(productName).subscribe((result:any)=>{console.log(result);
    this.searchedProduct = result; console.log(this.searchedProduct);});
  }

  */
 
