import { Component, OnInit } from '@angular/core';
import { CustomerService } from './../customer.service';
import { RouterModule, Router } from '@angular/router';
import {ToastrModule, ToastrService} from 'ngx-toastr';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
  customer: any
  
  constructor(private router: Router,private service: CustomerService,private toastr: ToastrService) {
    this.customer = {customerId: '', customerName: '', mobileNum: '',email: '',address: '',password:''} 
    
  }
 // title = 'AngularApp';

  ngOnInit(): void {
   // this.showToaster()  
  }
 // showToaster(){
   //  this.toastr.error ('Mobile Number not valid','Error');
 // } 
  registerSubmit(registerForm: any) {
    var pattern = /^[^ ]+@gmail.com$/;
    var mob = /^[1-9]{1}[0-9]{9}$/; 
   // var pattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;  
    if (this.customer.email.match(pattern)) {
      if (this.customer.mobileNum.match(mob)) {

  this.service.registerCustomer(registerForm).subscribe((result: any) => { 
    //  this.service.setCustomer('customer',JSON.stringify(result));
     // this.router.navigate(['login']);
      console.log(result); } );
    console.log(registerForm);
    this.toastr.success('','Successfully Registered');
    this.router.navigate(['login']);
  }
  else{
    
   // this.showToaster();
  //  alert("Mobile Number not valid");
  this.toastr.error('','Enter Valid Mobile Number');
  }     
  
    }
 else {

 // alert("Email not valid");
  this.toastr.error('','Enter Valid Email Address');


 
}
  }
}




/*
export class RegisterComponent implements OnInit {
  customer: any
  constructor(private router: Router,private service: CustomerService) {
    this.customer = {customerId: '', customerName: '', mobileNum: '',email: '',address: '',password:''} 
      
   }

  ngOnInit(): void {
  }

  registerSubmit(registerForm: any): void {
    this.service.registerCustomer(registerForm).subscribe((result: any) => { 
    //  this.service.setCustomer('customer',JSON.stringify(result));
     // this.router.navigate(['login']);
      console.log(result); } );
    console.log(registerForm);
    this.router.navigate(['login']);
  }



}

*/
