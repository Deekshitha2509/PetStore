import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';

declare var jQuery: any;

@Component({
  selector: 'app-myprofile',
  templateUrl: './myprofile.component.html',
  styleUrls: ['./myprofile.component.css']
})
export class MyprofileComponent implements OnInit {
  customer: any;
  editObject: any;
  constructor(private service: CustomerService) {
    this.customer=service.getCustomer('currentUser');
    this.editObject = {customerName: '', mobileNum: '',address: '',password: ''}
   }

  ngOnInit(): void {
  }
  showEditPopup(customer: any) {
    this.editObject = customer;
    jQuery('#customerModel').modal('show');
  }
  updateCustomer() {
    this.service.updateCustomer(this.editObject).subscribe();
    console.log(this.editObject);
  }
}
